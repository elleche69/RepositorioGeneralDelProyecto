




package Excepciones;



public class Nombres_mal extends Exception{

    public Nombres_mal(int h) {
                
        switch(h){
        
            case 0:
                javax.swing.JOptionPane.showMessageDialog(null, "Nombre mal introducido");                
                break;
        
            case 1:
                javax.swing.JOptionPane.showMessageDialog(null, "Primer apellido mal introducido");        
                break;
        
            case 2:
                javax.swing.JOptionPane.showMessageDialog(null, "Segundo apellido mal introducido");
                break;
                
            case 3:
                javax.swing.JOptionPane.showMessageDialog(null, "Calle mal introducida");
                break;
        
        }
        
        
        
        
        
    }
    
    
    
    
    
}
