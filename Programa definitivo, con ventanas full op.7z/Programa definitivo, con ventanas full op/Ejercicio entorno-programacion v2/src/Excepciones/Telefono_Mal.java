


package Excepciones;


public class Telefono_Mal extends Exception{
    
}
