
package Metodos;

import java.util.ArrayList;




public class MetodosComprobarDatosDeLasLineas {
    
    /**
     * Metodo que llama a otros metodos que verifican los datos de las nuevas lineas que el trabajador
     * de logistica esta añadiendo
     * @param data ArrayList que recibe los String de los datos que queremos erificar
     */
    
    public static void ElQueRecibeElArrayLost(ArrayList<String> data){    
        boolean a = ElQueCompruebaElContenidoDeLaCajaDeTexto(data.get(0));
        boolean b = ElQueCompruebaQueNoNosTimenConLasHoras(data.get(1), data.get(3), data.get(2), data.get(4));
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.DecidirSiInsertarONo(a, b, data);
    }    
        
        
    /**
     * Metodo que comprueba si el albaran nuevo es valido
     * @param numero_albaran
     * @return false o true segun lo que pase
     */    
        
    
    
    public static boolean ElQueCompruebaElContenidoDeLaCajaDeTexto(String numero_albaran){
    
        try{int op = Integer.parseInt(numero_albaran);} 
            
        catch(NumberFormatException e){   
            if(Metodos.MetodosComprobarInsultos.ComprobarArea(numero_albaran) == false){
                javax.swing.JOptionPane.showMessageDialog(null, "Numero de albaran debe de ser un numero");
                
            }
            else{
                javax.swing.JOptionPane.showMessageDialog(null, "Capron te vamos a meter una palisa", "GG", 2);
                
            }
            return true;
        }    
        return false;    
    }    
         
    
    
    /**
     * Metodo que comprueba que la hora de salida hacia el lugar no se despues de la hora de llegada desde ese lugar
     * (algo asi como comprobar que la cena no sea antes que el desayuno)
     * @param hora_antes trozo like "08"
     * @param hora_despues ""
     * @param min1 trozo like "59"
     * @param min2 ""
     * @return 
     */
         
                                       
        
        
    public static boolean ElQueCompruebaQueNoNosTimenConLasHoras(String hora_antes, String hora_despues, String min1, String min2){
            
        boolean a = false;
       
        if(Integer.parseInt(hora_antes) > Integer.parseInt(hora_despues)){a = true;}
        else{
            if (Integer.parseInt(hora_antes) == Integer.parseInt(hora_despues)){
                if(Integer.parseInt(min1) > Integer.parseInt(min2)){a = true;}
            }    
            else{}    
        }        
        return a;    
     }       
}        
        
        
        
        
        
        
        
        
    
    
        
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
