


package Metodos;

/**
 * Clase que se esperaba que iba a ser muy extensa
 * @author 1GBD09
 */



public class MetodosDeApoyoLineas {
 
    /**
     * Este metodo devuelve una hora como "08:59" en "08" y "59"
     * @param hora la hora "08:59"
     * @return el array de los trozos "08" y "59"
     */  
                        
    public static String[] DevolverTrozos(String hora){
    
        String[] trozos = hora.split(":");
        return trozos;
    }
       
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
