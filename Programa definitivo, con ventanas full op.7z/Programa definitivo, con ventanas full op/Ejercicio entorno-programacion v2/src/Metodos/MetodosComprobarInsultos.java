
package Metodos;


//Hice un nuevo paquete y una nueva clase para no tener tanto en la ventana partes

/**
 * Conjunto de metodos que comprueba que los trabajadores de logistica no introduzcan insultos en las cajas de texto
 * @author 1GBD09
 */


public class MetodosComprobarInsultos {
    
    
    private static final String[] insultos = {"Cabron","Cavron","Puta","Mecaguen","Muertos","Gilipollas","Poa","Putas","Puto","Retrasado","Mamahuevo","Chingon","Monger","Mongolo"};
    
    /**
     * Comprueba el area de incidencias
     * @param texto todo el texto del area
     * @return boolean b, su valor depende de si hay insultos o no
     */            
    
    public static boolean ComprobarArea(String texto){
        
        boolean b = false;    
        String[] desmembramiento_del_texto = texto.split(" ");
        
        int n = 0;
        
        int h = 0;
        
        while(n < desmembramiento_del_texto.length && b == false){
        
            while(h < insultos.length && b == false){
                if(!desmembramiento_del_texto[n].equalsIgnoreCase(insultos[h])){h = h + 1;}  
                else{b = true;}     
            }        
            h = 0;    
            n = n + 1;    
        }        
            
        return b;   
    }    
        
        
    
    public static void ComprobarTabla(){}
    
    
        
       
    
    
    
   
    
    
    
    
    
    
}
