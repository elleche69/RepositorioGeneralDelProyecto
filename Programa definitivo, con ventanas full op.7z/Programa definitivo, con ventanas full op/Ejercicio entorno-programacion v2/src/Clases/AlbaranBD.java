
package Clases;

/**
 *
 * @author 1GBD09
 */
public class AlbaranBD {
    
}
