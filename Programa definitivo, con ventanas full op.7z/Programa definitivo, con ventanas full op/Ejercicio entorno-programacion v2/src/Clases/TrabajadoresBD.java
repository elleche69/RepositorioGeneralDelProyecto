



package Clases;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author 1GBD09
 */
public class TrabajadoresBD extends GenericBD{
        
    public static Trabajadores trabajador = null;
    public static TrabajadoresLogistica logis = null;
    public static TrabajadoresAdministracion admin = null;
    
      public static Trabajadores Validar_Trabajadores(String dni, int id){
          Trabajadores f = null;
          
          int id_centro;
          try{
          
            GenerarConexion();
                                
            String busca = "select * from TRABAJADORESBD where DNI = ? and IDCENTRO = ?";
            
            PreparedStatement ps = GenericBD.getCon().prepareStatement(busca);
            
            ps.setString(1, dni);
            ps.setInt(2, id);
            
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                               
                f = new Trabajadores(resultado.getString(1),resultado.getString(2), resultado.getString(3), resultado.getString(4), resultado.getString(5), resultado.getString(6), resultado.getInt(7), resultado.getString(8), resultado.getString(9), resultado.getString(10), resultado.getFloat(12), resultado.getString(11));
                //trabajador = new Trabajadores(resultado.getString("DNI"),resultado.getString("NOMBRE"), resultado.getString("APELLIDO1"), resultado.getString("APELLIDO2"));
                
                ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.RecogerTipo(resultado.getString(14));
                
            }
           
            /*else{
            
                busca = "select * from TRABAJADORESBD where DNI = ?"; 
                ps = GenericBD.getCon().prepareStatement(busca);
                ps.setString(1, dni);
                resultado = ps.executeQuery();
                //Preguntar si quiere cambiar de centro
            }*/
            
            
          
          }
          catch(Exception e){System.out.print("w");}
          
          cerrarConexion();
          
          return f;
          
      
      
      }   
    
    
      
      
      
      public static void Modificar_datos(Trabajadores trabajador_modif, String tipo){
          
        try{  
          
            GenerarConexion();
          
            String update_parte1 = "Update TRABAJADORESBD "
                                +  "Set "
                                    + "Nombre = ?,  "
                                    + "Apellido1 = ?, "
                                    + "Apellido2 = ?, "
                                    + "Calle = ?, "
                                    + "Portal = ?, "
                                    + " Piso= ?, "
                                    + " Mano = ?, "
                                    + " TelMovil = ?, "
                                    + "TelPersonal = ?,  "
                                    + "Fechanac = ?, "
                                    + "Salario = ?, "
                                    + "Tipotrabajador = ? "
                                + "where dni = ?";
          
            PreparedStatement ps = GenericBD.getCon().prepareStatement(update_parte1);          
            ps.setString(1, trabajador_modif.getNombre());
            ps.setString(2, trabajador_modif.getApellido1());
            ps.setString(3, trabajador_modif.getApellido2());
            ps.setString(4, trabajador_modif.getCalle());
            ps.setInt(5, Integer.parseInt(trabajador_modif.getPortal()));
            ps.setInt(6, trabajador_modif.getPiso());
            ps.setString(7, trabajador_modif.getMano());
            ps.setString(8, trabajador_modif.getTelefono1());
            ps.setString(9, trabajador_modif.getTelefono2());
            ps.setString(10, trabajador_modif.getFecha_nac());
            ps.setFloat(11, trabajador_modif.getSalario()); 
            ps.setString(12, tipo);
            ps.setString(13, trabajador_modif.getDni());
            
            ps.executeUpdate();
            
            
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "Error inesperado");}
        
        cerrarConexion();  
      }
      
      
      public static void Borrar_Datos(String dni_mald){
      
        try{  

            GenerarConexion();

            String busca_y_borra = "Delete from TRABAJADORESBD where Upper(DNI) = ?";
                        
            PreparedStatement ps = GenericBD.getCon().prepareStatement(busca_y_borra);  
                   
            ps.setString(1, dni_mald);
            
            ps.executeUpdate();
            
            
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "Error inesperado");}

        cerrarConexion();  
        
      }
      
      
      
      public static void Añadir_Nuevo(Trabajadores trabajador, String tipo){
        
        try{
          GenerarConexion();
          String insertar = "Insert into TrabajadoresBD values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
          PreparedStatement ps = GenericBD.getCon().prepareStatement(insertar);
            ps.setString(1, trabajador.getDni());
            ps.setString(2, trabajador.getNombre());
            ps.setString(3, trabajador.getApellido1());
            ps.setString(4, trabajador.getApellido2());
            ps.setString(5, trabajador.getCalle());
            ps.setInt(6, Integer.parseInt(trabajador.getPortal()));
            ps.setInt(7, trabajador.getPiso());
            ps.setString(8, trabajador.getMano());
            ps.setString(9, trabajador.getTelefono1());
            ps.setString(10, trabajador.getTelefono2());
            ps.setString(11, trabajador.getFecha_nac());
            ps.setFloat(12, trabajador.getSalario()); 
            ps.setInt(13, trabajador.getCentro().getId());
            ps.setString(14, tipo);
           ps.executeQuery();
          
           
          
          
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "Error inesperado");}
        
      
      }
      
      
    public static boolean Comprobar(String dni){
          GenerarConexion();
          boolean b = false;
          
          try{
          
              String clausula = "Select * from TRABAJADORESBD where dni = ?";
              
              PreparedStatement ps = GenericBD.getCon().prepareStatement(clausula);
              
              ps.setString(1, dni);
              
              ResultSet set = ps.executeQuery();
              
              if(!set.next()){
              
                  b = true;
              
              }
              
          }
          catch(Exception e){
          
             
          }
          cerrarConexion();  
          return b;
          
          
    }
      
      
      
    public static void BuscarLogin(String dni){
           Trabajadores trabajadorf = null;
           logis = null;
           
           admin = null;
           
           GenerarConexion();
           try{
              
              String clausula = "Select * from TRABAJADORESBD where dni = ?";
              
              PreparedStatement ps = GenericBD.getCon().prepareStatement(clausula);
              
              ps.setString(1, dni);
              
              ResultSet resultado = ps.executeQuery();
              
              if(resultado.next()){
                    if(resultado.getString(14).equalsIgnoreCase("A")){ admin = new TrabajadoresAdministracion(resultado.getString(1),resultado.getString(2), resultado.getString(3), resultado.getString(4), resultado.getString(5), resultado.getString(6), resultado.getInt(7), resultado.getString(8), resultado.getString(9), resultado.getString(10), resultado.getFloat(11), resultado.getString(12), resultado.getString(13));}                                                                       
                    else{logis = new TrabajadoresLogistica(resultado.getString(1),resultado.getString(2), resultado.getString(3), resultado.getString(4), resultado.getString(5), resultado.getString(6), resultado.getInt(7), resultado.getString(8), resultado.getString(9), resultado.getString(10), resultado.getFloat(11), resultado.getString(12), resultado.getString(13));}
              }    
              ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.LograrTipoLogin(logis, admin);
            }        
                                     
            catch(Exception e){
                System.out.print("g");
             
          }
          cerrarConexion();  
          
    } 
      
      
    public static void Cambiar_de_centro(int id_despues, int id_antes){
      
        GenerarConexion();
        String update = "Update trabajadoresbd set IDCENTRO = ? where IDCENTRO = ?";
        
        try{
            PreparedStatement ps = GenericBD.getCon().prepareCall(update);
            ps.setInt(1, id_antes);
            ps.setInt(2, id_despues);
            ps.executeUpdate();
        }
        catch(Exception e){}
        cerrarConexion();
    }  
    
    
    public static Trabajadores LograrTrabajadorPorDni(String dni){
    
        Trabajadores trabajadorr = null;
        
        GenericBD.GenerarConexion();
        String busqueda = "Select * from trabajadoresbd where dni = ?";
        try{
        
            PreparedStatement ps = GenericBD.getCon().prepareStatement(busqueda);
            ps.setString(1, dni);
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
            
                trabajadorr = new Trabajadores(resultado.getString(1), resultado.getString(2), resultado.getString(3), resultado.getString(4));
            
            }
            
        }
        catch(Exception e){}
        
        
        
        
    
    
    
        return trabajadorr;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}    

      
      
    

//AGUA eotxoa@amvisa-futura.org