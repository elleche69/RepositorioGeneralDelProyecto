
package Clases;

import java.util.Date;


public class Partes {
    
    private int id;
    
    private int km_inicio;
    
    private int km_final;
    
    private int gastos_gasoil;
    
    private int gastos_peaje;
    
    private int gastos_dietas;
    
    private int otros_gastos;
        
    public String fecha; // 
    
    public String estado;
    
    private String incidencias;
      
    private Trabajadores trabajador_logis;
    
    private Trabajadores trabajador_admin;

    private Vehiculo vehiculo;
    
    
    public Partes(int id, int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, String incidencias, Trabajadores trabajador_logis) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.incidencias = incidencias;
        this.trabajador_logis = trabajador_logis;
    }

    public Partes(int id, int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, String incidencias, Trabajadores trabajador_logis, Trabajadores trabajador_admin) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.incidencias = incidencias;
        this.trabajador_logis = trabajador_logis;
        this.trabajador_admin = trabajador_admin;
    }

    public Partes(int id, TrabajadoresLogistica trabajador_logis, TrabajadoresAdministracion trabajador_admin) {
        this.id = id;
        this.trabajador_logis = trabajador_logis;
        this.trabajador_admin = trabajador_admin;
    }

    public Partes(int id, int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, String fecha, String estado, String incidencias) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.fecha = fecha;
        this.estado = estado;
        this.incidencias = incidencias;
    }

    public Partes(int id, String fecha, String estado, Trabajadores trabajador_logis) {
        this.id = id;
        this.fecha = fecha;
        this.estado = estado;
        this.trabajador_logis = trabajador_logis;
    }

    public Partes(int id, int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, String fecha, Trabajadores trabajador_logis, Vehiculo vehiculo) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.fecha = fecha;
        this.trabajador_logis = trabajador_logis;
        this.vehiculo = vehiculo;
    }

    public Partes(int id, int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, String fecha, String estado, String incidencias, Trabajadores trabajador_logis, Vehiculo vehiculo) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.fecha = fecha;
        this.estado = estado;
        this.incidencias = incidencias;
        this.trabajador_logis = trabajador_logis;
        this.vehiculo = vehiculo;
    }

    public Partes(int id,int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, Trabajadores trabajador_admin, Vehiculo vehiculo) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.trabajador_admin = trabajador_admin;
        this.vehiculo = vehiculo;
    }

    public Partes(int id, int km_inicio, int km_final, int gastos_gasoil, int gastos_peaje, int gastos_dietas, int otros_gastos, String fecha, String estado, String incidencias, Trabajadores trabajador_logis, Trabajadores trabajador_admin, Vehiculo vehiculo) {
        this.id = id;
        this.km_inicio = km_inicio;
        this.km_final = km_final;
        this.gastos_gasoil = gastos_gasoil;
        this.gastos_peaje = gastos_peaje;
        this.gastos_dietas = gastos_dietas;
        this.otros_gastos = otros_gastos;
        this.fecha = fecha;
        this.estado = estado;
        this.incidencias = incidencias;
        this.trabajador_logis = trabajador_logis;
        this.trabajador_admin = trabajador_admin;
        this.vehiculo = vehiculo;
    }

    

    
    
    
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKm_inicio() {
        return km_inicio;
    }

    public void setKm_inicio(int km_inicio) {
        this.km_inicio = km_inicio;
    }

    public int getKm_final() {
        return km_final;
    }

    public void setKm_final(int km_final) {
        this.km_final = km_final;
    }

    public int getGastos_gasoil() {
        return gastos_gasoil;
    }

    public void setGastos_gasoil(int gastos_gasoil) {
        this.gastos_gasoil = gastos_gasoil;
    }

    public int getGastos_peaje() {
        return gastos_peaje;
    }

    public void setGastos_peaje(int gastos_peaje) {
        this.gastos_peaje = gastos_peaje;
    }

    public int getGastos_dietas() {
        return gastos_dietas;
    }

    public void setGastos_dietas(int gastos_dietas) {
        this.gastos_dietas = gastos_dietas;
    }

    public int getOtros_gastos() {
        return otros_gastos;
    }

    public void setOtros_gastos(int otros_gastos) {
        this.otros_gastos = otros_gastos;
    }

    public String getIncidencias() {
        return incidencias;
    }

    public void setIncidencias(String incidencias) {
        this.incidencias = incidencias;
    }

    public Trabajadores getTrabajador_logis() {
        return trabajador_logis;
    }

    public void setTrabajador_logis(Trabajadores trabajador_logis) {
        this.trabajador_logis = trabajador_logis;
    }

    public Trabajadores getTrabajador_admin() {
        return trabajador_admin;
    }

    public void setTrabajador_admin(Trabajadores trabajador_admin) {
        this.trabajador_admin = trabajador_admin;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
    
    
    
    
}
