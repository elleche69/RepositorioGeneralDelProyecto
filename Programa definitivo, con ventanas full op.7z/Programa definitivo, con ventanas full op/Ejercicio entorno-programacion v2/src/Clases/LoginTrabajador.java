

package Clases;





public class LoginTrabajador {
    
    private String usuario;
    
    private String password;
    
    private Trabajadores trabajador;

    public LoginTrabajador(String usuario, String password, Trabajadores trabajador) {
        this.usuario = usuario;
        this.password = password;
        this.trabajador = trabajador;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Trabajadores getTrabajador() {
        return trabajador;
    }

    public void setTrabajador(Trabajadores trabajador) {
        this.trabajador = trabajador;
    }
    
    
    
    
    
    
    
    
    
    
    
}
