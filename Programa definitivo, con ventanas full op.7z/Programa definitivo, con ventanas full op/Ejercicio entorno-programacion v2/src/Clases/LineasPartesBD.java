



package Clases;

import static Clases.GenericBD.GenerarConexion;
import static Clases.GenericBD.cerrarConexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;



public class LineasPartesBD {
    
    public static ArrayList<LineaPartes> Buscar(Partes parto){
        
        ArrayList<LineaPartes> t_parto = new ArrayList();
        
        try{
            GenericBD.GenerarConexion();
            
            String sentencia = "Select * from lineasbd where Num_parte = ? order by id_parte";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(sentencia);
            preparado.setInt(1, parto.getId());
            ResultSet resultado = preparado.executeQuery();
            System.out.print("Te parto");
            while(resultado.next()){
            
                LineaPartes t_parte = new LineaPartes(resultado.getInt(1), resultado.getString(2), resultado.getString(3), new Albaran(resultado.getInt(5)));
                t_parto.add(t_parte);
            }    
        }
        catch(Exception r){}    
           
        GenericBD.cerrarConexion();
        return t_parto;    
    }
            
        
    public static void AñadirLineaNuevaEnBD(LineaPartes linea){
        GenericBD.GenerarConexion();
        try{
            String Lista = "Insert into lineasbd values(?,?,?,?,?)";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(Lista);
            preparado.setInt(1, linea.getId());
            preparado.setString(2, linea.getHora_salida());
            preparado.setString(3, linea.getHora_llegada());
            preparado.setInt(4, linea.getParte().getId());
            preparado.setInt(5, linea.getAlbaran().getNum_albaran());            
            preparado.executeUpdate();
        }
        
        
        
        
        
        
        catch(Exception r){}
        GenericBD.cerrarConexion();
        
    
    
    
    
    
    
    
    }
        
    
    
    
    
    
    public static int GenerarId(){
    
        int id = 1;
        GenerarConexion(); 
        try{
            
            String busqueda = "select nvl(max(id_parte),0) from lineasbd";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(busqueda);
            ResultSet resultado = preparado.executeQuery(); 
            if(resultado.next()){
                id = resultado.getInt(1);
            }
            
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, e);}
        cerrarConexion();
        return id;
    }
    
    
    public static void UpdatePorElAdmin(LineaPartes linea){
    
        GenericBD.GenerarConexion();
        try{
        
            String update = "Update lineasbd set hora_salida = ?, hora_llegada = ?, num_albaran = ? where id_parte = ?";
            PreparedStatement pt = GenericBD.getCon().prepareCall(update);
            pt.setString(1, linea.getHora_salida());
            pt.setString(2, linea.getHora_llegada());
            pt.setInt(3, linea.getAlbaran().getNum_albaran());
            pt.setInt(4, linea.getId());
            pt.executeUpdate();
        
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, e);}
        cerrarConexion();
    }
    
    
    public static void BorrarLineasDeEseParte(int id){
    
        GenericBD.GenerarConexion();
        String delete = "Delete from lineasbd where num_parte = ?";
        try{
       
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(delete);
            preparado.setInt(1, id);
            preparado.executeUpdate();
            PartesBD.BorrarParte(id);
                               
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, e);}
    
    
    } 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
