/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import Clases.Centros;
import java.awt.Color;
import java.awt.Label;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author 1GBD09
 */
public class CRUDCentros extends javax.swing.JFrame {

    
    public CRUDCentros() {
        initComponents();
        this.getContentPane().setBackground(Color.GRAY);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tx_id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tx_nombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tx_direccion = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tx_portal = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tx_cod3 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tx_ciudad = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tx_provincia = new javax.swing.JTextField();
        te = new javax.swing.JLabel();
        tx_telefono = new javax.swing.JTextField();
        boton_ok = new javax.swing.JButton();
        boton_salir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        jLabel4.setText("jLabel4");

        jLabel10.setText("jLabel10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DATOS DEL CENTRO");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Id del centro");

        tx_id.setEnabled(false);
        tx_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tx_idActionPerformed(evt);
            }
        });
        tx_id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tx_idKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tx_idKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombre del centro");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Calle del centro");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Nº portal del centro");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Codigo postal del centro");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Ciudad donde esta el centro");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Provincia donde se ubica");

        te.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        te.setForeground(new java.awt.Color(255, 255, 255));
        te.setText("Telefono del centro");

        boton_ok.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        boton_ok.setText("jButton1");
        boton_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton_okActionPerformed(evt);
            }
        });

        boton_salir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        boton_salir.setText("Salir");
        boton_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton_salirActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("La Bala Transportes S. Coop.");

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_mini_velocidad_transp_dcha.gif"))); // NOI18N

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_mini_velocidad_transp_izda.gif"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addContainerGap(72, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel12))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(te)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tx_provincia, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_cod3, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_portal, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_id, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(94, 94, 94))
            .addGroup(layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(boton_ok)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(boton_salir)
                .addGap(80, 80, 80))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(201, 201, 201)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tx_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tx_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tx_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tx_portal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tx_cod3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tx_ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(tx_provincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tx_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(te))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boton_ok)
                    .addComponent(boton_salir))
                .addGap(27, 27, 27)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tx_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tx_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tx_idActionPerformed

    private void tx_idKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tx_idKeyPressed
        
        
        
        
        
    }//GEN-LAST:event_tx_idKeyPressed

    private void tx_idKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tx_idKeyReleased
        Matcher c = patron.matcher(tx_id.getText());        
        if(c.matches()){
            boolean e = ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.ComprobarIdCentroNuevo(Integer.parseInt(tx_id.getText()));            
            if (e == true){
                MensajeError();
            }
            else{
                ActivarDesactivar(true);
                boton_ok.setEnabled(true);
            }}
         else{MensajeError();}             
        //Con esto me cargo el timer
    }//GEN-LAST:event_tx_idKeyReleased

    private void boton_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton_okActionPerformed
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.FinalizarAccion(opcionx, LograrDatos());
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.EleccionGenerarVentanas(1, 2);
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.ConseguirIdsDeLaBase(0);
    }//GEN-LAST:event_boton_okActionPerformed

    private void boton_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton_salirActionPerformed
       
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.EleccionGenerarVentanas(1, 2);
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.ConseguirIdsDeLaBase(0);
    }//GEN-LAST:event_boton_salirActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CRUDCentros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CRUDCentros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CRUDCentros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CRUDCentros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CRUDCentros().setVisible(true);
            }
        });
    }

    /**
     * Setter del Objeto centros, tambien recibe el indice de la accion que se
     * desea realizar
     * @param centro el objeto
     * @param opcion la opcion
     */
        
    public void RecogerCentro(Centros centro, int opcion){
        centr = centro;
        opcionx = opcion;
        PonerNombreActionXMas();
    
    }
    
    /**
     * Metodo que segun la opcion modifica el texto que contiene el boton,
     * tambien llama a los metodos de activacion o desactivacion de las TextFields
     */
    private void PonerNombreActionXMas(){    
        switch (opcionx){        
            case 1:
                ActivarDesactivar(false);
                boton_ok.setText("Insertar nuevo");
                break;
            case 2:
                ActivarDesactivar(true);
                EnseñarDatosEnCajas();
                boton_ok.setText("Modificar centro");
                break;
            case 3: 
                ActivarDesactivar(false);
                EnseñarDatosEnCajas();
                boton_ok.setText("Borrar centro");
                break;
        }
    }    
    
    /**
     * Activa o desactiva los componentes segun el parametro booleano recibido
     * @param b true o false
     */
        
    private void ActivarDesactivar(boolean b){
        
        if (b == false && opcionx != 3){tx_id.setEnabled(true);}        
        tx_nombre.setEnabled(b);
        tx_direccion.setEnabled(b);
        tx_portal.setEnabled(b);
        tx_cod3.setEnabled(b);
        tx_ciudad.setEnabled(b);
        tx_provincia.setEnabled(b);
        tx_telefono.setEnabled(b);        
    }    
    
    /**
     * Metodo que inserta los datos del centro(existente) en las textfields
     */
    private void EnseñarDatosEnCajas(){    
        tx_id.setText(centr.getId() + "");
        tx_nombre.setText(centr.getNombre());
        tx_direccion.setText(centr.getCalle());
        tx_portal.setText(centr.getNumero() + "");
        tx_cod3.setText(centr.getCodigo() + "");
        tx_ciudad.setText(centr.getCiudad());
        tx_provincia.setText(centr.getProvincia());
        tx_telefono.setText(centr.getTelefono());
    }
    
    
    /**
     * Getter de los datos introducidos en los componentes
     * @return 
     */
    
    private ArrayList<String> LograrDatos(){
    
        ArrayList<String> data = new ArrayList();
    
        if (opcionx != 3){        
            data.add(tx_id.getText());
            data.add(tx_nombre.getText());
            data.add(tx_direccion.getText());
            data.add(tx_portal.getText());
            data.add(tx_cod3.getText());
            data.add(tx_ciudad.getText());
            data.add(tx_provincia.getText());
            data.add(tx_telefono.getText());        
        }
        else{data.add(tx_id.getText());}
            
        
        return data;
    }
    
    
    /**
     * Validaciones
     */
    
    private void Validaciones(){//Como las de Crud_Trabajadores
    
    }
    
    
    
    private void MensajeError(){}
    
    
    private final Pattern patron2 = Pattern.compile("^[A-Z+]$");
    private final Pattern patron = Pattern.compile("^[0-9]+$");
    private Centros centr;
    private int opcionx;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton_ok;
    private javax.swing.JButton boton_salir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel te;
    private javax.swing.JTextField tx_ciudad;
    private javax.swing.JTextField tx_cod3;
    private javax.swing.JTextField tx_direccion;
    private javax.swing.JTextField tx_id;
    private javax.swing.JTextField tx_nombre;
    private javax.swing.JTextField tx_portal;
    private javax.swing.JTextField tx_provincia;
    private javax.swing.JTextField tx_telefono;
    // End of variables declaration//GEN-END:variables
}
