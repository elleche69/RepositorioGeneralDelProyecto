/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import Metodos.MetodosDeApoyoLineas;
import Clases.LineaPartes;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author 1GBD09
 */
public class VentanaLineas extends javax.swing.JFrame {

   
    public VentanaLineas() {
        initComponents();
        this.getContentPane().setBackground(Color.GRAY);
        
        
    }
    
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        num_albaran = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        añadir = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setSize(new java.awt.Dimension(800, 719));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Numero Albaran");

        num_albaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                num_albaranActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tiempo Ida");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));
        jComboBox1.setCursor(new java.awt.Cursor(java.awt.Cursor.W_RESIZE_CURSOR));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText(":");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText(":");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Tiempo vuelta");

        añadir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        añadir.setText("Añadir la linea");
        añadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                añadirActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton2.setText("Salir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/imagen_ventana_lineas.jpg"))); // NOI18N
        jLabel7.setText("jLabel7");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 802, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("AÑADIR LÍNEAS AL PARTE");

        jPanel2.setBackground(new java.awt.Color(255, 204, 102));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setText("La Bala Transportes S. Coop.");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_mini_velocidad_transp_izda.gif"))); // NOI18N

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_mini_velocidad_transp_dcha.gif"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addGap(187, 187, 187))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8))
            .addComponent(jLabel10)
            .addComponent(jLabel9)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(jLabel6))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(61, 61, 61)
                            .addComponent(jLabel1)
                            .addGap(18, 18, 18)
                            .addComponent(num_albaran, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(76, 76, 76)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(añadir)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addGap(117, 117, 117))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(num_albaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 535, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(añadir)
                    .addComponent(jButton2))
                .addGap(29, 29, 29)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void num_albaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_num_albaranActionPerformed
        
        
    }//GEN-LAST:event_num_albaranActionPerformed

    private void añadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_añadirActionPerformed
              
        
      Recuperar_Datos();   
      
        
        
    }//GEN-LAST:event_añadirActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        
    }//GEN-LAST:event_formWindowOpened

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.EleccionGenerarVentanas(1, 7);
        
        
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * Metodo que activa el conjunto de componentes para añadir una linea nueva en su totalidad a la ventana
     * n es igual a la Y de la "Linea original, esta se va aumentando a cada linea nueva insertada. Se utiliza para situar la posicion de la nueva linea debajo de la linea anterior"
     */
    
    
    public void Añadir_nueva_linea(){     
        if (indie < 15){
            n = n + 30;  
            Añadir_Label1();
            Añadir_CampoTexto1();
            Añadir_Label2();
            Añadir_ComboBox1();
            Añadir_Label3();
            Añadir_Combo2();
            Añadir_Label4();
            Añadir_Combo3();
            Añadir_Label5();
            Añadir_Combo4();            
            indie = indie + 1;}
         else{añadir.setEnabled(false);}
    }       
           
        
          
        
       
        
        
    
    /**
     * Metodo que añade un nuevo label identico al primer "label original"
     */
    
    private void Añadir_Label1(){             
        this.add(label = new JLabel()).setBounds(jLabel1.getX(), n , jLabel1.getWidth(), jLabel1.getHeight());
        label.setText(jLabel1.getText());    
        
    }
    
    /**
     * Metodo que añade un campo de texto nuevo identico al primer "campo de texto original"
     */
    
    private void Añadir_CampoTexto1(){                    
        this.add(text = new JTextField()).setBounds(num_albaran.getX(), n, num_albaran.getWidth(), num_albaran.getHeight());
    }    
    
    /**
     * Metodo que añade un nuevo label identico al segundo "label original"
     */
    
    
    private void Añadir_Label2(){
        this.add(label2 = new JLabel()).setBounds(jLabel2.getX(), n, jLabel2.getWidth(), jLabel2.getHeight());
        label2.setText(jLabel2.getText());
    }    
        
    
    /**
     * Metodo que añade un nuevo comboBox identico al primer "comboBox original"
     */
    
    private void Añadir_ComboBox1(){
        this.add(combo1 = new JComboBox()).setBounds(jComboBox1.getX(), n, jComboBox1.getWidth(), jComboBox1.getHeight());
        int nx = 0;
        
        while (nx < jComboBox1.getItemCount()){        
            combo1.addItem(jComboBox1.getItemAt(nx));
            nx = nx + 1;        
        }
    }    
    /**
     * Metodo que añade un nuevo label identico al tercer "label original"
     */
    
    
    private void Añadir_Label3(){
        this.add(label3 = new JLabel()).setBounds(jLabel3.getX(), n, jLabel3.getWidth(), jLabel3.getHeight());
        label3.setText(jLabel3.getText());
    
    }
    
    /**
     * Metodo que añade un nuevo comboBox identico al segundo "comboBox original"
     */
    
    private void Añadir_Combo2(){
        this.add(combo2 = new JComboBox()).setBounds(jComboBox2.getX(), n, jComboBox2.getWidth(), jComboBox2.getHeight());
        int nx = 0;
        
        while (nx < jComboBox2.getItemCount()){        
            combo2.addItem(jComboBox2.getItemAt(nx));
            nx = nx + 1;        
        }
    }
    
    /**
     * Metodo que añade un nuevo label identico al cuarto "label original"
     */
    
    private void Añadir_Label4(){
        this.add(label4 = new JLabel()).setBounds(jLabel5.getX(), n,jLabel5.getWidth(), jLabel5.getHeight());
        label4.setText(jLabel5.getText());
    }
    
    
    /**
     * Metodo que añade un nuevo label identico al tercer "comboBox original"
     */
    
    
    private void Añadir_Combo3(){
    
        this.add(combo3 = new JComboBox()).setBounds(jComboBox4.getX(), n, jComboBox4.getWidth(), jComboBox4.getHeight());
        int nx = 0;
        
        while (nx < jComboBox4.getItemCount()){        
            combo3.addItem(jComboBox4.getItemAt(nx));
            nx = nx + 1;        
        }
        
    }
    
    
    /**
     * Metodo que añade un nuevo label identico al quinto "label original"
     */
    
    
    private void Añadir_Label5(){
        this.add(label5 = new JLabel()).setBounds(jLabel4.getX(), n, jLabel4.getWidth(), jLabel4.getHeight());
        label5.setText(jLabel4.getText());
    
    }
    
    
    /**
     * Metodo que añade un nuevo comboBox identico al cuarto "comboBox original"
     */
    
    
    
    private void Añadir_Combo4(){
    
        this.add(combo4 = new JComboBox()).setBounds(jComboBox3.getX(), n, jComboBox3.getWidth(), jComboBox3.getHeight());
        int nx = 0;
        
        while (nx < jComboBox3.getItemCount()){        
            combo4.addItem(jComboBox3.getItemAt(nx));
            nx = nx + 1;        
        }
    }
    
   
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaLineas().setVisible(true);
            }
        });
    }
    
    
    
    /**
     * Metodo que sirve para recuperar los datos de la nueva linea insertada
     * Como no me di cuenta de que podria haberlo hecho con solo la linea original tuve que usar un if para saber de que linea 
     * tiene que recuperar los datos, para ello uso la variable n, si n es igual que la y de la primera linea original significara
     * que no se han añadido o recuperado de bd ninguna otra.
     */
    
    private void Recuperar_Datos(){
    
        data = new ArrayList();
        
        if (n  == this.jLabel1.getY()){
            if(!num_albaran.getText().isEmpty()){
                data.add(num_albaran.getText());
                data.add(jComboBox1.getSelectedItem().toString());
                data.add(jComboBox2.getSelectedItem().toString());
                data.add(jComboBox4.getSelectedItem().toString());
                data.add(jComboBox3.getSelectedItem().toString());
                
                ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Recuperar_Datos_Lineas(data, 0);
            }
            else{javax.swing.JOptionPane.showMessageDialog(null, "Numero de albaran es obligatorio");}
        }    
        
    
        else{
            if(!text.getText().isEmpty()){
                data.add(text.getText());
                data.add(combo1.getSelectedItem().toString());
                data.add(combo2.getSelectedItem().toString());
                data.add(combo3.getSelectedItem().toString());
                data.add(combo4.getSelectedItem().toString());
                
                ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Recuperar_Datos_Lineas(data, 1);
            }
            else{javax.swing.JOptionPane.showMessageDialog(null, "Numero de albaran es obligatorio");}
        }
        
    }    
        
     
    
    /**
     * Metodo que sirve para añadir a la ventana lineas que fueron metidas con anterioridad en un parte
     * @param lineas_del_parte es el ArrayList de objetos LineasPartes devuelto 
     */
    public void AñadirLineasQueYaEstan(ArrayList<LineaPartes> lineas_del_parte){
    
        n  = this.jLabel1.getY();
        int d = 0;
        while(d < lineas_del_parte.size()){
            SeleccionarItems(Metodos.MetodosDeApoyoLineas.DevolverTrozos(lineas_del_parte.get(d).getHora_salida()), Metodos.MetodosDeApoyoLineas.DevolverTrozos(lineas_del_parte.get(d).getHora_llegada()), lineas_del_parte.get(d).getAlbaran().getNum_albaran(), d);            
            DesactivarLineas(d);
            Añadir_nueva_linea();
            d = d + 1;
        }
    }
    
    
    
    
    
        
    /**
     * Metodo que complementa el anterior, este sirve para dejar seleccionado la hora recogida de bd de cada linea en las combo box
     * @param hora_partida trozo de la hora like "08"
     * @param hora_partida2 trozo de la hora like "59"
     * @param numero_alb numero de albaran
     * @param indice indice que marca si desactivar la "linea original" o la "linea copia"
     */    
        
      
    public void SeleccionarItems(String[] hora_partida, String[] hora_partida2, int numero_alb, int indice){
    
        if(indice == 0){
            num_albaran.setText(numero_alb + "");
            jComboBox1.setSelectedItem(hora_partida[0]);
            jComboBox2.setSelectedItem(hora_partida[1]);            
            jComboBox4.setSelectedItem(hora_partida2[0]);
            jComboBox3.setSelectedItem(hora_partida2[1]);
        }
        else{
            text.setText(numero_alb + "");
            combo1.setSelectedItem(hora_partida[0]);            
            combo2.setSelectedItem(hora_partida[1]);
            combo3.setSelectedItem(hora_partida2[0]);
            combo4.setSelectedItem(hora_partida[1]);
        }
    
    
    
    }
    
    /**
     * Metodo que desactiva la linea nueva que YA acaba de ser insertada, nosotros no le damos posibilidad de editar o eliminar lineas
     * al trabajador de logistica, en nuestra empresa las equivocaciones se pagan con sangre
     * @param d indice que marca si desactivar la "linea original" o la copia.
     */
    
    
  
    public void DesactivarLineas(int d){
    
        if(d == 0){
            num_albaran.setEnabled(false);     
            num_albaran.setDisabledTextColor(Color.blue);                        
            jComboBox1.setEnabled(false);                 
            jComboBox2.setEnabled(false);
            jComboBox3.setEnabled(false);
            jComboBox4.setEnabled(false);
        }    
                        
        else{
            text.setEnabled(false);
            text.setDisabledTextColor(Color.blue);
            combo1.setEnabled(false);
            combo2.setEnabled(false);
            combo3.setEnabled(false);
            combo4.setEnabled(false);
        }   
    }        
            
        
       
        
        
        
    
    
      
      
      
      
      
      
      
    
    
    
    
   
    
    
    
    
    
    
    private JComboBox<String> combo1;
    private JComboBox<String> combo2;
    private JComboBox<String> combo3;    
    private JComboBox<String> combo4;
  
    private JLabel label;
    private JLabel label2;  
    private JLabel label3; 
    private JLabel label4;
    private JLabel label5;
    private int indie = 0;
    
    private JTextField text;
    private int jk = 0;
    private int n;
    private ArrayList<String> data;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton añadir;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField num_albaran;
    // End of variables declaration//GEN-END:variables
}
