


package Ventanas;

import Clases.LineaPartes;
import Clases.Partes;
import ModelosTablas.ModeloTablaPartesAdm;
import ModelosTablas.ModeloTablaPartesEdicion;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.event.*;
import java.time.MonthDay;
import java.time.Year;



public class VentanaAdministrarPartes extends javax.swing.JFrame {

  
    
    
    public VentanaAdministrarPartes() {
        initComponents();
        this.getContentPane().setBackground(Color.GRAY);
        
    }    
        
        
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panel1 = new javax.swing.JPanel();
        fecha1 = new javax.swing.JFormattedTextField();
        fecha2 = new javax.swing.JFormattedTextField();
        label = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        mostrar = new javax.swing.JButton();
        panel_tabla = new javax.swing.JPanel();
        panel_referencia = new javax.swing.JPanel();
        panel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        panel_de_control = new javax.swing.JPanel();
        crear_informe = new javax.swing.JButton();
        pag_ant = new javax.swing.JButton();
        pag_siguiente = new javax.swing.JButton();
        label_resultados = new javax.swing.JLabel();
        num = new javax.swing.JLabel();
        volver = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        panel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)), "Filtrado de partes\n", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(255, 255, 255))); // NOI18N

        fecha1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("dd/MM/yyyy"))));
        fecha1.setText("01/01/1961");

        fecha2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("dd/MM/yyyy"))));
        fecha2.setText("12/12/2016");

        label.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        label.setForeground(new java.awt.Color(255, 255, 255));
        label.setText("Del");

        label2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        label2.setForeground(new java.awt.Color(255, 255, 255));
        label2.setText("Hasta");

        mostrar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        mostrar.setText("Mostrar");
        mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(label)
                .addGap(31, 31, 31)
                .addComponent(fecha1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(143, 143, 143)
                .addComponent(label2)
                .addGap(34, 34, 34)
                .addComponent(fecha2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
                .addComponent(mostrar)
                .addGap(117, 117, 117))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label)
                    .addComponent(fecha1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label2)
                    .addComponent(fecha2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mostrar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel_tabla.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)), "Resultados\n", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(255, 255, 255))); // NOI18N

        javax.swing.GroupLayout panel_referenciaLayout = new javax.swing.GroupLayout(panel_referencia);
        panel_referencia.setLayout(panel_referenciaLayout);
        panel_referenciaLayout.setHorizontalGroup(
            panel_referenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 811, Short.MAX_VALUE)
        );
        panel_referenciaLayout.setVerticalGroup(
            panel_referenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        panel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)), "Datos del parte\n", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(255, 255, 255))); // NOI18N

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)},
                {null, null, null, null, null, null, null, null, null, null, null, null,  new Boolean(false)}
            },
            new String [] {
                "Id", "Km inicio", "Km final", "G.gasoil", "G. peaje", "G. dietas", "Otros g.", "Fecha", "Estado", "Incidencias", "Dni trab", "Vehiculo", "Editar"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        crear_informe.setText("Crear informe");
        crear_informe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crear_informeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_de_controlLayout = new javax.swing.GroupLayout(panel_de_control);
        panel_de_control.setLayout(panel_de_controlLayout);
        panel_de_controlLayout.setHorizontalGroup(
            panel_de_controlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_de_controlLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(crear_informe)
                .addGap(117, 117, 117))
        );
        panel_de_controlLayout.setVerticalGroup(
            panel_de_controlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_de_controlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(crear_informe)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pag_ant.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        pag_ant.setText("Pagina anterior");
        pag_ant.setBorderPainted(false);
        pag_ant.setEnabled(false);
        pag_ant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pag_antActionPerformed(evt);
            }
        });

        pag_siguiente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        pag_siguiente.setText("Pagina siguiente");
        pag_siguiente.setBorderPainted(false);
        pag_siguiente.setEnabled(false);
        pag_siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pag_siguienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_tablaLayout = new javax.swing.GroupLayout(panel_tabla);
        panel_tabla.setLayout(panel_tablaLayout);
        panel_tablaLayout.setHorizontalGroup(
            panel_tablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_tablaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_tablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_tablaLayout.createSequentialGroup()
                        .addGroup(panel_tablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(panel_de_control, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_tablaLayout.createSequentialGroup()
                        .addGap(0, 72, Short.MAX_VALUE)
                        .addComponent(panel_referencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))))
            .addGroup(panel_tablaLayout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(pag_ant)
                .addGap(197, 197, 197)
                .addComponent(label_resultados)
                .addGap(40, 40, 40)
                .addComponent(num, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pag_siguiente)
                .addGap(86, 86, 86))
        );
        panel_tablaLayout.setVerticalGroup(
            panel_tablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_tablaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel_referencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_tablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pag_ant)
                    .addComponent(pag_siguiente)
                    .addComponent(label_resultados)
                    .addComponent(num, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panel_de_control, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        volver.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        volver.setText("Volver al menu");
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ADMINISTRACIÓN DE PARTES");

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("La Bala Transportes S. Coop.");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_mini_velocidad_transp_dcha.gif"))); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ventanas/Imagenes/la_bala_mini_velocidad_transp_izda.gif"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(238, 238, 238))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2))
            .addComponent(jLabel3)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panel_tabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(21, 21, 21)
                            .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(293, 293, 293)
                            .addComponent(jLabel1))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(422, 422, 422)
                            .addComponent(volver))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panel_tabla, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(volver)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarActionPerformed
        
        ComprobarOrdenFechas();
        GuardarDatos();   
    }//GEN-LAST:event_mostrarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        try{
            AccionEditar();
        }
        catch(Exception e){}
        
    }//GEN-LAST:event_tablaMouseClicked

    private void pag_antActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pag_antActionPerformed
        
        num_pagina = num_pagina - 1;
        PasarFechas(-1);
        
    }//GEN-LAST:event_pag_antActionPerformed

    private void pag_siguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pag_siguienteActionPerformed
        num_pagina = num_pagina + 1;
        PasarFechas(1);
        
        
        
        
    }//GEN-LAST:event_pag_siguienteActionPerformed

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.EleccionGenerarVentanas(3, 1);
        
    }//GEN-LAST:event_volverActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
      
        int dia = MonthDay.now().getDayOfMonth();
                        
        
        mes = MonthDay.now().getMonthValue();
        
        año = Integer.parseInt(Year.now().toString().substring(2));        
        
        if(mes == 1){
            mes = 12;
        }
        else{mes = mes - 1;}
        
        
        FechasInforme(año, mes, dia);
        
        
        
        
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_formWindowOpened

    private void crear_informeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crear_informeActionPerformed
        
        if(mes < 10){ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.CrearParser("0"+mes + "/" + año);}
        else{ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.CrearParser(mes + "/" + año);}
        
        crear_informe.setEnabled(false);
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_crear_informeActionPerformed

    
    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaAdministrarPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaAdministrarPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaAdministrarPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaAdministrarPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaAdministrarPartes().setVisible(true);
            }
        });
    }

              
    /**
     * Metodo que hace de setter del ArrayList de objetos de tipo partes l_partes
     * @param partes el ArrayList que se le pasa
     */
    
    public void RecojerPartes(ArrayList<Partes> partes){
    
        l_partes = partes;
        AñadirListaPartesALaTabla();
    }
    
    
    /**
     * Metodo que se encarga de añadir los datos de un parte en cada fila
     */
    
    public void AñadirListaPartesALaTabla(){
    
        int n = 0;
        VaciarTabla();
        while(n < l_partes.size()){        
            tabla.setValueAt(l_partes.get(n).getId(), n , 0);
            tabla.setValueAt(l_partes.get(n).getKm_inicio(), n, 1);
            tabla.setValueAt(l_partes.get(n).getKm_final(), n, 2);
            tabla.setValueAt(l_partes.get(n).getGastos_gasoil(), n, 3);
            tabla.setValueAt(l_partes.get(n).getGastos_peaje(), n, 4);
            tabla.setValueAt(l_partes.get(n).getGastos_dietas(), n, 5);
            tabla.setValueAt(l_partes.get(n).getOtros_gastos(), n, 6);
            AñadirFechaEnTablaLikeAOracleSQL(n);
            tabla.setValueAt(l_partes.get(n).getEstado(), n, 8);
            if (l_partes.get(n).getIncidencias() == null){tabla.setValueAt("No", n, 9);}
            else{tabla.setValueAt("Si", n, 9);}            
            tabla.setValueAt(l_partes.get(n).getTrabajador_logis().getDni(), n, 10);                
            tabla.setValueAt(l_partes.get(n).getVehiculo().getMatricula(), n, 11);    
            n = n + 1;
        }
        
        
        
    }
    
    
    /**
     * Metodo que se utiliza para poner la fecha en el formato de Oracle SQL
     * @param n indice de la fila en la que se ha de añadir la fecha
     */
    
            
   public void AñadirFechaEnTablaLikeAOracleSQL(int n){
      
        String[] trozos = l_partes.get(n).getFecha().split("-");        
        String fecha_modo_ok = trozos[2]+ "/" + trozos[1] + "/" + trozos[0];   
        tabla.setValueAt(fecha_modo_ok, n, 7);
    }
   
   
   

    
    
    public void ComprobarOrdenFechas(){
    
        String data1 = fecha1.getText();
        String data2 = fecha2.getText();
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.BusquedaPorFecha(data1, data2);
    }    
       
    
    
    /**
     * Metodo que pasa las fechas para la busqueda de los partes
     * @param j es igual a la hoja de resultados actual
     */
    public void PasarFechas(int j){    
        if(j == 1){
            ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.BusquedaPorFecha(tabla.getValueAt(14, 7).toString(), marcador_fecha_fin);
        }
        else{ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.BusquedaPorFecha(fecha_prim, marcador_fecha_fin);}
    }
    
    
    
    //Formato fechas java no coincide con los de sql
    
    /**
     * Metodo que guarda desde el principio las fechas introducidas en las dos formated fields
     */
    
    public void GuardarDatos(){
        
        fecha_prim = fecha1.getText();
        marcador_fecha_fin = fecha2.getText();
    }
    
    
    
    /**
     * Otro metodo setter???? pendiente de comprobar si esta repetido
     * @param pa 
     */
    public void RecuperarResultados(ArrayList<Partes> pa){
    
        l_partes = pa;
        AñadirListaPartesALaTabla();
    }
    
    /**
     * Metodo que recibe un int con el numero de partes recuperados de la busqueda 
     * y lo introduce en un label, tambien gestiona si activar los botones de 
     * pagina siguiente o pagina anterior
     * @param numero el numero de resultados obtenido
     */
    
    public void RecuperarNumeroDeResultados(int numero){
    
        if(num_pagina == 0){
            pag_ant.setEnabled(false);
            num.setText(numero + " resultados");
            if(numero > 15){pag_siguiente.setEnabled(true);}
            else{}
        }
        else{
            pag_ant.setEnabled(true);
            if(num_pagina - numero < 15){pag_siguiente.setEnabled(false);}
           
        }    
    }    
        
        
        
       
    
    
    /**
     * Metodo para vaciar filas de la tabla no utilizadas anteriormente
     */
  
    
    
    public void VaciarTabla(){
    
        int n = 0;
        while(n < 15){        
            tabla.setValueAt("", n , 0);
            tabla.setValueAt("", n, 1);
            tabla.setValueAt("", n, 2);
            tabla.setValueAt("", n, 3);
            tabla.setValueAt("", n, 4);
            tabla.setValueAt("", n, 5);
            tabla.setValueAt("", n, 6);
            tabla.setValueAt("", n, 7);
            tabla.setValueAt("", n, 8);
            tabla.setValueAt("", n, 9);                       
            tabla.setValueAt("", n, 10);                
            tabla.setValueAt("", n, 11);    
            tabla.setValueAt(new Boolean(false), n, 12);
            n = n + 1;
        }
    
    
    }
      
    
    
    /**
     * Metodo que segun la fila checkbox de editar seleccionada pasa el parte correspondiente a la ventana de edicion
     */
   
    public void AccionEditar(){
    
        int n = 0;
        int o = 0;
        
        while(n < l_partes.size()){            
                        
            if((boolean)tabla.getValueAt(n, 12) != false){
                o = n;
                n = l_partes.size() + 1;
            }    
            else{n = n + 1;}
        } 
        
        
        EmpiezaLaVentanaEdicion(o);
        
    }    
        
        
        
        
        
        
    public void EmpiezaLaVentanaEdicion(int n){
        
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.PasarElParteElegidoParaEditar(l_partes.get(n));
        
    }    
    
        
    
    
   public void FechasInforme(int año, int mes, int dia){
    
       ArrayList<String> fechas =  ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.RetornaElArrayList();
    
       int n = 0;
       boolean r = true;
       if(!fechas.isEmpty()){
            while(n < fechas.size()){

                int troceo = Integer.parseInt(fechas.get(n).split("/")[0]);
                int troceo2 = Integer.parseInt(fechas.get(n).split("/")[1]);

                if(mes == troceo && año == troceo2){
                    n = fechas.size() + 1;
                    r = false;
                 }
                else{n = n + 1;}

            }
       }
       else{}
       crear_informe.setEnabled(r);}
     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
      
        
   
    
       
        
    
    
    
    
    
    
    private int mes;
    private int año;
    
    
        
    
    private int num_pagina = 0;
    private int ind = - 1;
    private int indicador_edicion = 0;        
    
    private String fecha_prim;
    private String marcador_fecha_fin;
    
    
    private ArrayList<Partes> l_pag_anterior;
    private ArrayList<Partes> l_partes;
    private ArrayList<LineaPartes> lineas;
    
    private ModeloTablaPartesAdm primer_modelo;
    private ModeloTablaPartesEdicion modelo_edicion = new ModeloTablaPartesEdicion();
    
    private DefaultTableModel segundo_modelo;
    
    private ArrayList<Boolean> refencia_valor;
    
    private JTable tabla_de_las_lineas;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton crear_informe;
    private javax.swing.JFormattedTextField fecha1;
    private javax.swing.JFormattedTextField fecha2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label_resultados;
    private javax.swing.JButton mostrar;
    private javax.swing.JLabel num;
    private javax.swing.JButton pag_ant;
    private javax.swing.JButton pag_siguiente;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel3;
    private javax.swing.JPanel panel_de_control;
    private javax.swing.JPanel panel_referencia;
    private javax.swing.JPanel panel_tabla;
    private javax.swing.JTable tabla;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables
}
